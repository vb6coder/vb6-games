The Xenology Crisis v0.2.0
www.baronsoft.com
4/6/2003

License:

	The source code, from this package, is released under the GNU Public License. All content (graphics, sound, and story material) , from this package, are copyrighted by the orginal TXC team and All Rights Are Reserved.
	In other words, you can distribute the source code, from this package, under the terms on the GNUGPL. The content, from this package, cannot be distributed.

Information:
	This package includes all of the source code to The Xenology Crisis. TXC was an online RPG that existed during the 1996-1999 timeframe. The source code is being released for educational purposes, since it is closely related to ORE. There are several main differences between ORE and TXC though:
	1. TXC uses a Hex Engine, where all odd columns are shifted up half a tile. To see this 		simply open up the map editor and click show grid.
	2. TXC is more featured rich than OREv040. It includes a merchant system, more advanced 		AI and combat system, an Arena, and Enforcer system. The Enforcer system allows 		GM selected players to police other players. Helps curve PvP killing and controls 		annoying players..
	3. TXC is also more buggy than ORE. I stripped out alot of extra features in ORE because 		they introduced bugs.
	4. TXC uses DirectX6 instead of DX7 for OREv040 or DX8 for OREv050.

	While, I'd like to allow free distribution of the content included in this package, it simply does not belong to me. I've long lost contact with many members of the team and I am unable to ask their permission "give away" the content. The source code was all done by me though so I've decided to release it under the GNUGPL.

Hope you enjoy this,

Aaron Perkins
aaron@baronsoft.com

