
If you run the Exe file and pressing play mp3 you will get a error message, becuse there is no mp3.
Becouse i used a file calld TLN.mp3 so if you wan't to lisen without editing the code just copy a mp3 file and rename it TLN.mp3

One other thing...
I have no idea what to do with it...

/Fredrik Alexandersson