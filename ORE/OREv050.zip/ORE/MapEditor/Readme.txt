Map Editor 0.9.1 created by Fredrik Alexandersson fredrik@oraklet.zzn.com

Whats New in clsTileEngineX?
-Nothing

New in editor Map Editor 0.9.1

A new icon.
Using Alpha Blending for particle systems.
Took away the stuff that was crap in the last release.

Whats need to be fixed:
Rotation Tool still dosn't Work Properly.